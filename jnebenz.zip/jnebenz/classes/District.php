<?php
/*
* 2007-2014 PrestaShop
*
* NOTICE OF LICENSE
*
* This source file is subject to the Open Software License (OSL 3.0)
* that is bundled with this package in the file LICENSE.txt.
* It is also available through the world-wide-web at this URL:
* http://opensource.org/licenses/osl-3.0.php
* If you did not receive a copy of the license and are unable to
* obtain it through the world-wide-web, please send an email
* to license@prestashop.com so we can send you a copy immediately.
*
* DISCLAIMER
*
* Do not edit or add to this file if you wish to upgrade PrestaShop to newer
* versions in the future. If you wish to customize PrestaShop for your
* needs please refer to http://www.prestashop.com for more information.
*
*  @author PrestaShop SA <contact@prestashop.com>
*  @copyright  2007-2014 PrestaShop SA
*  @license    http://opensource.org/licenses/osl-3.0.php  Open Software License (OSL 3.0)
*  International Registered Trademark & Property of PrestaShop SA
*/

class District extends ObjectModel
{
	/** @var integer city id which district belongs */
	public $id_city;

	/** @var integer Zone id which district belongs */
	public $id_zone;

	/** @var string 2 letters iso code */
	public $iso_code;

	/** @var string Name */
	public $district;

	/** @var boolean Status for delivery */
	public $active = true;

	/**
	 * @see ObjectModel::$definition
	 */
	public static $definition = array(
		'table' => 'district',
		'primary' => 'id_district',
		'fields' => array(
			'id_city' => array('type' => self::TYPE_INT, 'validate' => 'isUnsignedId', 'required' => true),
			'id_zone' => 	array('type' => self::TYPE_INT, 'validate' => 'isUnsignedId', 'required' => true),
			'iso_code' => 	array('type' => self::TYPE_STRING, 'validate' => 'isDistrictIsoCode', 'required' => true, 'size' => 7),
			'district' => 		array('type' => self::TYPE_STRING, 'validate' => 'isGenericName', 'required' => true, 'size' => 32),
			'active' => 	array('type' => self::TYPE_BOOL, 'validate' => 'isBool'),
		),
	);

	protected $webserviceParameters = array(
		'fields' => array(
			'id_zone' => array('xlink_resource'=> 'zones'),
			'id_city' => array('xlink_resource'=> 'city')
		),
	);

	public static function getDistrict($id_lang = false, $active = false)
	{
		return Db::getInstance(_PS_USE_SQL_SLAVE_)->executeS('
		SELECT `id_district`, `id_city`, `id_zone`, `iso_code`, `district`, `active`
		FROM `'._DB_PREFIX_.'district`
		'.($active ? 'WHERE active = 1' : '').'
		ORDER BY `district` ASC');
	}

	/**
	 * Get a district name with its ID
	 *
	 * @param integer $id_district City ID
	 * @return string District
	 */
	public static function getNameById($id_district)
	{
		if (!$id_district)
			return false;
		$cache_id = 'District::getNameById_'.(int)$id_district;
		if (!Cache::isStored($cache_id))
		{
			$result = Db::getInstance(_PS_USE_SQL_SLAVE_)->getValue('
				SELECT `district`
				FROM `'._DB_PREFIX_.'district`
				WHERE `id_district` = '.(int)$id_district
			);
			Cache::store($cache_id, $result);
		}
		return Cache::retrieve($cache_id);
	}

	/**
	 * Get a district id with its name
	 *
	 * @param string $id_district City ID
	 * @return integer district id
	 */
	public static function getIdByName($district)
	{
		if (empty($district))
			return false;
		$cache_id = 'District::getNameById_'.pSQL($district);
		if (!Cache::isStored($cache_id))
		{
			$result = (int)Db::getInstance()->getValue('
				SELECT `id_district`
				FROM `'._DB_PREFIX_.'district`
				WHERE `name` LIKE \''.pSQL($district).'\'
			');
			Cache::store($cache_id, $result);
		}
		return Cache::retrieve($cache_id);
	}

	/**
	* Get a district id with its iso code
	*
	* @param string $iso_code Iso code
	* @return integer district id
	*/
	public static function getIdByIso($iso_code, $id_city = null)
	{
	  	return Db::getInstance()->getValue('
		SELECT `id_district`
		FROM `'._DB_PREFIX_.'district`
		WHERE `iso_code` = \''.pSQL($iso_code).'\'
		'.($id_city ? 'AND `id_city` = '.(int)$id_city : ''));
	}

	/**
	* Delete a district only if is not in use
	*
	* @return boolean
	*/
	public function delete()
	{
		if (!$this->isUsed())
		{
			// Database deletion
			$result = Db::getInstance()->delete($this->def['table'], '`'.$this->def['primary'].'` = '.(int)$this->id);
			if (!$result)
				return false;

			// Database deletion for multilingual fields related to the object
			if (!empty($this->def['multilang']))
				Db::getInstance()->delete(bqSQL($this->def['table']).'_lang', '`'.$this->def['primary'].'` = '.(int)$this->id);
			return $result;
		}
		else
			return false;
	}

	/**
	 * Check if a district is used
	 *
	 * @return boolean
	 */
	public function isUsed()
	{
		return ($this->countUsed() > 0);
	}

	/**
	 * Returns the number of utilisation of a city
	 *
	 * @return integer count for this city
	 */
	public function countUsed()
	{
		$result = Db::getInstance(_PS_USE_SQL_SLAVE_)->getValue('
			SELECT COUNT(*)
			FROM `'._DB_PREFIX_.'address`
			WHERE `'.$this->def['primary'].'` = '.(int)$this->id
		);
		return $result;
	}

    public static function getDistrictByIdCity($id_city)
    {
        if (empty($id_city))
            die(Tools::displayError());

        return Db::getInstance()->executeS('
        SELECT *
        FROM `'._DB_PREFIX_.'district` d
        WHERE d.`id_city` = '.(int)$id_city
        );
    }

	public static function getIdZone($id_district)
	{
		if (!Validate::isUnsignedId($id_district))
			die(Tools::displayError());

		return Db::getInstance(_PS_USE_SQL_SLAVE_)->getValue('
			SELECT `id_zone`
			FROM `'._DB_PREFIX_.'district`
			WHERE `id_district` = '.(int)$id_district
		);
	}

	/**
	 * @param $ids_district
	 * @param $id_zone
	 * @return bool
	 */
	public function affectZoneToSelection($ids_district, $id_zone)
	{
		// cast every array values to int (security)
		$ids_district = array_map('intval', $ids_district);
		return Db::getInstance()->execute('
		UPDATE `'._DB_PREFIX_.'district` SET `id_zone` = '.(int)$id_zone.' WHERE `id_district` IN ('.implode(',', $ids_district).')
		');
	}
}

