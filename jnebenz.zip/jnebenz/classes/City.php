<?php
/*
* 2007-2014 PrestaShop
*
* NOTICE OF LICENSE
*
* This source file is subject to the Open Software License (OSL 3.0)
* that is bundled with this package in the file LICENSE.txt.
* It is also available through the world-wide-web at this URL:
* http://opensource.org/licenses/osl-3.0.php
* If you did not receive a copy of the license and are unable to
* obtain it through the world-wide-web, please send an email
* to license@prestashop.com so we can send you a copy immediately.
*
* DISCLAIMER
*
* Do not edit or add to this file if you wish to upgrade PrestaShop to newer
* versions in the future. If you wish to customize PrestaShop for your
* needs please refer to http://www.prestashop.com for more information.
*
*  @author PrestaShop SA <contact@prestashop.com>
*  @copyright  2007-2014 PrestaShop SA
*  @license    http://opensource.org/licenses/osl-3.0.php  Open Software License (OSL 3.0)
*  International Registered Trademark & Property of PrestaShop SA
*/

class City extends ObjectModel
{
	/** @var integer State id which city belongs */
	public $id_state;

	/** @var integer Zone id which city belongs */
	public $id_zone;

	/** @var string 2 letters iso code */
	public $iso_code;

	/** @var string Name */
	public $name;

	/** @var boolean Status for delivery */
	public $active = true;

	/**
	 * @see ObjectModel::$definition
	 */
	public static $definition = array(
		'table' => 'city',
		'primary' => 'id_city',
		'fields' => array(
			'id_state' => array('type' => self::TYPE_INT, 'validate' => 'isUnsignedId', 'required' => true),
			'id_zone' => 	array('type' => self::TYPE_INT, 'validate' => 'isUnsignedId', 'required' => true),
			'iso_code' => 	array('type' => self::TYPE_STRING, 'validate' => 'isCityIsoCode', 'required' => true, 'size' => 7),
			'name' => 		array('type' => self::TYPE_STRING, 'validate' => 'isGenericName', 'required' => true, 'size' => 32),
			'active' => 	array('type' => self::TYPE_BOOL, 'validate' => 'isBool'),
		),
	);

	protected $webserviceParameters = array(
		'fields' => array(
			'id_zone' => array('xlink_resource'=> 'zones'),
			'id_state' => array('xlink_resource'=> 'states')
		),
	);

	public static function getCities($id_lang = false, $active = false)
	{
		return Db::getInstance(_PS_USE_SQL_SLAVE_)->executeS('
		SELECT `id_city`, `id_state`, `id_zone`, `iso_code`, `name`, `active`
		FROM `'._DB_PREFIX_.'city`
		'.($active ? 'WHERE active = 1' : '').'
		ORDER BY `name` ASC');
	}

	/**
	 * Get a city name with its ID
	 *
	 * @param integer $id_city State ID
	 * @return string City name
	 */
	public static function getNameById($id_city)
	{
		if (!$id_city)
			return false;
		$cache_id = 'City::getNameById_'.(int)$id_city;
		if (!Cache::isStored($cache_id))
		{
			$result = Db::getInstance(_PS_USE_SQL_SLAVE_)->getValue('
				SELECT `name`
				FROM `'._DB_PREFIX_.'city`
				WHERE `id_city` = '.(int)$id_city
			);
			Cache::store($cache_id, $result);
		}
		return Cache::retrieve($cache_id);
	}

	/**
	 * Get a city id with its name
	 *
	 * @param string $id_city State ID
	 * @return integer city id
	 */
	public static function getIdByName($city)
	{
		if (empty($city))
			return false;
		$cache_id = 'City::getNameById_'.pSQL($city);
		if (!Cache::isStored($cache_id))
		{
			$result = (int)Db::getInstance()->getValue('
				SELECT `id_city`
				FROM `'._DB_PREFIX_.'city`
				WHERE `name` LIKE \''.pSQL($city).'\'
			');
			Cache::store($cache_id, $result);
		}
		return Cache::retrieve($cache_id);
	}

	/**
	* Get a city id with its iso code
	*
	* @param string $iso_code Iso code
	* @return integer city id
	*/
	public static function getIdByIso($iso_code, $id_state = null)
	{
	  	return Db::getInstance()->getValue('
		SELECT `id_city`
		FROM `'._DB_PREFIX_.'city`
		WHERE `iso_code` = \''.pSQL($iso_code).'\'
		'.($id_state ? 'AND `id_state` = '.(int)$id_state : ''));
	}

	/**
	* Delete a city only if is not in use
	*
	* @return boolean
	*/
	public function delete()
	{
		if (!$this->isUsed())
		{
			// Database deletion
			$result = Db::getInstance()->delete($this->def['table'], '`'.$this->def['primary'].'` = '.(int)$this->id);
			if (!$result)
				return false;

			// Database deletion for multilingual fields related to the object
			if (!empty($this->def['multilang']))
				Db::getInstance()->delete(bqSQL($this->def['table']).'_lang', '`'.$this->def['primary'].'` = '.(int)$this->id);
			return $result;
		}
		else
			return false;
	}

	/**
	 * Check if a city is used
	 *
	 * @return boolean
	 */
	public function isUsed()
	{
		return ($this->countUsed() > 0);
	}

	/**
	 * Returns the number of utilisation of a city
	 *
	 * @return integer count for this city
	 */
	public function countUsed()
	{
		$result = Db::getInstance(_PS_USE_SQL_SLAVE_)->getValue('
			SELECT COUNT(*)
			FROM `'._DB_PREFIX_.'address`
			WHERE `'.$this->def['primary'].'` = '.(int)$this->id
		);
		return $result;
	}

    public static function getCitiesByIdState($id_state)
    {
        if (empty($id_state))
            die(Tools::displayError());

        return Db::getInstance()->executeS('
        SELECT *
        FROM `'._DB_PREFIX_.'city` s
        WHERE s.`id_state` = '.(int)$id_state
        );
    }

	public static function hasCounties($id_city)
	{
		return count(County::getCounties((int)$id_city));
	}

	public static function getIdZone($id_city)
	{
		if (!Validate::isUnsignedId($id_city))
			die(Tools::displayError());

		return Db::getInstance(_PS_USE_SQL_SLAVE_)->getValue('
			SELECT `id_zone`
			FROM `'._DB_PREFIX_.'city`
			WHERE `id_city` = '.(int)$id_city
		);
	}

	/**
	 * @param $ids_cities
	 * @param $id_zone
	 * @return bool
	 */
	public function affectZoneToSelection($ids_cities, $id_zone)
	{
		// cast every array values to int (security)
		$ids_cities = array_map('intval', $ids_cities);
		return Db::getInstance()->execute('
		UPDATE `'._DB_PREFIX_.'city` SET `id_zone` = '.(int)$id_zone.' WHERE `id_city` IN ('.implode(',', $ids_cities).')
		');
	}
}

