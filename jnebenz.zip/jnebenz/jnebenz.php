<?php
/*
* 2007-2014 PrestaShop
*
* NOTICE OF LICENSE
*
* This source file is subject to the Academic Free License (AFL 3.0)
* that is bundled with this package in the file LICENSE.txt.
* It is also available through the world-wide-web at this URL:
* http://opensource.org/licenses/afl-3.0.php
* If you did not receive a copy of the license and are unable to
* obtain it through the world-wide-web, please send an email
* to license@prestashop.com so we can send you a copy immediately.
*
* DISCLAIMER
*
* Do not edit or add to this file if you wish to upgrade PrestaShop to newer
* versions in the future. If you wish to customize PrestaShop for your
* needs please refer to http://www.prestashop.com for more information.
*
*  @author PrestaShop SA <contact@prestashop.com>
*  @copyright  2007-2014 PrestaShop SA
*  @license    http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
*  International Registered Trademark & Property of PrestaShop SA
*/

/**
 * @since   1.5.0
 * @version 1.3 (2012-03-14)
 */

if (!defined('_PS_VERSION_'))
  exit;
 
class JneBenz extends Module
{
  public function __construct()
  {
    $this->name = 'jnebenz';
    $this->tab = 'front_office_features';
    $this->version = '1.0.0';
    $this->author = 'Benz - PT Sartono Media';
    $this->need_instance = 1;
    $this->ps_versions_compliancy = array('min' => '1.6', 'max' => _PS_VERSION_); 
    $this->bootstrap = true;
 
    parent::__construct();
    $this->displayName = $this->l('JNE Benz');
    $this->description = $this->l('PRESTASHOP - JNE Shipping Module - by PT Sartono Media (www.sartono-media.com)');
 
    $this->confirmUninstall = $this->l('Are you sure you want to uninstall?');
 
    if (!Configuration::get('MYMODULE_NAME'))      
      $this->warning = $this->l('No name provided');
    
			$sql = 'CREATE TABLE IF NOT EXISTS '._DB_PREFIX_.'city (';
			$sql .= ' id_city 			Integer(10) UNSIGNED NOT NULL AUTO_INCREMENT,';
			$sql .= ' id_state 		Integer(11) UNSIGNED NOT NULL,';
			$sql .= ' id_zone      Integer(11) UNSIGNED NOT NULL,';
			$sql .= ' `name`       NVarChar(64) COLLATE utf8_general_ci NOT NULL,';
			$sql .= ' iso_code     NVarChar(7) COLLATE utf8_general_ci NOT NULL,';
			$sql .= ' tax_behavior SmallInt(1) NOT NULL DEFAULT 0,';
			$sql .= ' active       TinyInt(1) NOT NULL DEFAULT 0,'; 
			$sql .= ' PRIMARY KEY (';
			$sql .= ' id_city';
			$sql .= ' )';
			$sql .= ' ) ENGINE=InnoDB DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;';		
			if (!Db::getInstance()->execute($sql))
	    die('Error Creating table city.');
	    
	    $sql = 'CREATE TABLE IF NOT EXISTS '._DB_PREFIX_.'district (';
			$sql .= ' id_district  Integer(10) UNSIGNED NOT NULL AUTO_INCREMENT,';
			$sql .= ' id_city      Integer(11) UNSIGNED NOT NULL,';
			$sql .= ' id_zone      Integer(11) UNSIGNED NOT NULL,';
			$sql .= ' district     NVarChar(64) COLLATE utf8_general_ci NOT NULL,';
			$sql .= ' iso_code     NVarChar(7) COLLATE utf8_general_ci NOT NULL,';
			$sql .= ' tax_behavior SmallInt(1) NOT NULL DEFAULT 0,';
			$sql .= ' active       TinyInt(1) NOT NULL DEFAULT 0,'; 
			$sql .= ' PRIMARY KEY (';
			$sql .= ' id_district';
			$sql .= '   )';
			$sql .= ' ) ENGINE=InnoDB DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;';
			if (!Db::getInstance()->execute($sql))
	    die('Error creating table district.');
	    
	    //$sql='delete from '._DB_PREFIX_.'carrier;'
			//Db::getInstance()->execute($sql);
			//if (!Db::getInstance()->execute($sql))
	    //if (!Db::getInstance()->delete(_DB_PREFIX_.'carrier'))
	    //die('Erreur etc.');
	    
	    //$sql='INSERT INTO '._DB_PREFIX_.'carrier (id_carrier, id_reference, id_tax_rules_group, `name`, url, active, deleted, shipping_handling, range_behavior, is_module, is_free, shipping_external, need_range, external_module_name, shipping_method, position, max_width, max_height, max_depth, max_weight, grade) VALUES (3,3,0,"JNE","",1,0,0,0,0,0,0,0,"",1,1,0,0,0,0,0);'
			//Db::getInstance()->execute($sql);
			//if (!Db::getInstance()->execute($sql))
	    //die('Erreur etc.');
	    
	    $sql = "SELECT count(*) FROM information_schema.COLUMNS WHERE TABLE_NAME='"._DB_PREFIX_."address' AND COLUMN_NAME='id_city';";
			if(Db::getInstance()->getValue($sql)==0){
				Db::getInstance()->disconnect();
				Db::getInstance()->connect();
		    $sql = 'ALTER TABLE `'._DB_PREFIX_.'address` ADD `id_city` integer(10)';
				if (!Db::getInstance()->execute($sql))
		    die('Error Creating Field City-.');
			}	

	    $sql = "SELECT count(*) FROM information_schema.COLUMNS WHERE TABLE_NAME='"._DB_PREFIX_."address' AND COLUMN_NAME='id_district';";
			if(Db::getInstance()->getValue($sql)==0){
				Db::getInstance()->disconnect();
				Db::getInstance()->connect();
		    $sql = 'ALTER TABLE `'._DB_PREFIX_.'address` ADD `id_district` integer(10)';
				if (!Db::getInstance()->execute($sql))
		    die('Error Creating Field District-.');
			}	

			/*
			$file = fopen("ps_range_weight.csv","r");
			while(! feof($file))
  		{
  			$fld = fgetcsv($file);
  			$sql = "insert into " . _DB_PREFIX_ . "range_weight(id_carrier,delimiter1,delimiter2) values ('".$fld[1]."','".$fld[2]."','".$fld[3]."');";
				Db::getInstance()->execute($sql);
  		}
			fclose($file);
			*/

  }
}

?>